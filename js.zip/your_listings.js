// =========================================
// ReWear - Your Listings
// =========================================

let swapRequests = [];
let activeUser = "You";

// -----------------------------
// Load Page
// -----------------------------
document.addEventListener("DOMContentLoaded", () => {

    loadAndRenderListings();

});

// -----------------------------
// Get Requests
// -----------------------------
function getSwapRequests() {

    const stored = localStorage.getItem("swapRequests");

    if (!stored) {

        return [];

    }

    try {

        return JSON.parse(stored);

    } catch (e) {

        return [];

    }

}

// -----------------------------
// Save Requests
// -----------------------------
function saveSwapRequests(data) {

    localStorage.setItem(
        "swapRequests",
        JSON.stringify(data)
    );

}

// -----------------------------
// Load + Render
// -----------------------------
function loadAndRenderListings() {

    swapRequests = getSwapRequests();

    sortRequests();

    renderListings();

}
// -----------------------------
// Render Listings
// -----------------------------
function renderListings() {

    const grid = document.getElementById("listings-dynamic-grid");
    const emptyState = document.getElementById("empty-state");
    const count = document.getElementById("request-count");

    grid.innerHTML = "";

    count.textContent = swapRequests.length;

    if (swapRequests.length === 0) {

        emptyState.style.display = "flex";
        grid.style.display = "none";

        return;
    }

    emptyState.style.display = "none";
    grid.style.display = "grid";

    swapRequests.forEach((request, index) => {

        const card = document.createElement("div");
        card.className = "listing-card";

        let badgeClass = "pending";

        if (request.status === "Accepted") {
            badgeClass = "accepted";
        }

        if (request.status === "Rejected") {
            badgeClass = "rejected";
        }

        card.innerHTML = `

        <div class="listing-image">

            <img src="${request.userImage}"
                 alt="Your Item">

        </div>

        <div class="listing-content">

            <h3>${request.userItem}</h3>

            <p class="swap-for">

                <strong>Swap For:</strong>

                ${request.targetItem}

            </p>

            <p>

                <strong>Estimated Value:</strong>

                ₹${request.targetPrice}

            </p>

            <p>

                <strong>Requested On:</strong>

                ${request.date}

            </p>

            <div class="status-row">

                <span class="status-badge ${badgeClass}">

                    ${request.status}

                </span>

            </div>

            <div class="progress">

                ${getProgress(request.status)}

            </div>

            <button class="delete-btn"
                    onclick="deleteRequest(${index})">

                Delete

            </button>

        </div>

        `;

        grid.appendChild(card);

    });

}
// ==========================================
// Progress Tracker
// ==========================================

function getProgress(status) {

    if (status === "Pending") {

        return `
            <div class="progress-wrapper">

                <div class="progress-step completed">
                    ✔ Request Sent
                </div>

                <div class="progress-step active">
                    ⏳ Waiting for Owner
                </div>

                <div class="progress-step">
                    Swap Complete
                </div>

            </div>
        `;

    }

    if (status === "Accepted") {

        return `
            <div class="progress-wrapper">

                <div class="progress-step completed">
                    ✔ Request Sent
                </div>

                <div class="progress-step completed">
                    ✔ Accepted
                </div>

                <div class="progress-step completed">
                    ✔ Swap Complete
                </div>

            </div>
        `;

    }

    return `
        <div class="progress-wrapper">

            <div class="progress-step completed">
                ✔ Request Sent
            </div>

            <div class="progress-step rejected">
                ✖ Rejected
            </div>

        </div>
    `;

}



// ==========================================
// Delete One Request
// ==========================================

function deleteRequest(index) {

    const confirmDelete = confirm(
        "Delete this swap request?"
    );

    if (!confirmDelete) return;

    swapRequests.splice(index, 1);

    saveSwapRequests(swapRequests);

    loadAndRenderListings();

}



// ==========================================
// Clear Entire History
// ==========================================

function clearAllSwaps() {

    const ok = confirm(
        "Clear all swap history?"
    );

    if (!ok) return;

    localStorage.removeItem("swapRequests");

    swapRequests = [];

    loadAndRenderListings();

}



// ==========================================
// Sort Requests
// ==========================================

function sortRequests() {

    const sort = document.getElementById("sort-requests");

    if (!sort) return;

    switch (sort.value) {

        case "oldest":

            swapRequests.sort((a, b) =>
                a.id - b.id
            );

            break;

        case "price-high":

            swapRequests.sort((a, b) =>
                b.targetPrice - a.targetPrice
            );

            break;

        case "price-low":

            swapRequests.sort((a, b) =>
                a.targetPrice - b.targetPrice
            );

            break;

        case "status":

            swapRequests.sort((a, b) => {

                const order = {
                    Pending: 1,
                    Accepted: 2,
                    Rejected: 3
                };

                return order[a.status] - order[b.status];

            });

            break;

        default:

            swapRequests.sort((a, b) =>
                b.id - a.id
            );

    }

}



// ==========================================
// Active User
// ==========================================

function switchActiveUser(name) {

    activeUser = name;

    loadAndRenderListings();

}
// ==========================================
// Validate Old Saved Data
// ==========================================

function normalizeRequests() {

    let updated = false;

    swapRequests.forEach(request => {

        if (!request.id) {

            request.id = Date.now() + Math.floor(Math.random() * 10000);
            updated = true;

        }

        if (!request.status) {

            request.status = "Pending";
            updated = true;

        }

        if (!request.date) {

            request.date = new Date().toLocaleDateString(
                "en-IN",
                {
                    day: "2-digit",
                    month: "long",
                    year: "numeric"
                }
            );

            updated = true;

        }

        if (!request.userItem) {

            request.userItem = "My Clothing Item";
            updated = true;

        }

        if (!request.targetItem) {

            request.targetItem = "Requested Item";
            updated = true;

        }

        if (!request.userImage) {

            request.userImage =
                "assets/no-image.png";

            updated = true;

        }

        if (!request.targetPrice) {

            request.targetPrice = 0;

            updated = true;

        }

    });

    if (updated) {

        saveSwapRequests(swapRequests);

    }

}



// ==========================================
// Reload Automatically
// ==========================================

window.addEventListener("storage", () => {

    loadAndRenderListings();

});




// ==========================================
// First Time Initialization
// ==========================================

(function () {

    swapRequests = getSwapRequests();

    normalizeRequests();

    loadAndRenderListings();

})();



// ==========================================
// Debug Helper
// Remove later if you want
// ==========================================

console.log(
    "✅ ReWear Your Listings Loaded Successfully"
);
const request = {

    targetItem:
        document.getElementById("selectedItemName").textContent,

    targetImage:
        document.getElementById("selectedItemImage").src,

    targetPrice:
        document.getElementById("selectedItemValue").textContent,

    category:
        document.getElementById("selectedItemCategory").textContent,

    status:"Pending",

    date:new Date().toLocaleDateString()

};